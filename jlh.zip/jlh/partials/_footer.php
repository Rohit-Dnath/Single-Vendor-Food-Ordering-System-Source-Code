<div class="footer container-fluid bg-primary text-dark">
    <p class="text-center py-2 mb-0">Copyright © 2023 Just Like Home <a href="https://rohitdnath-protfolio-web.netlify.app/" target="_blank" rel="noopener noreferrer"></a></p>
</div>
